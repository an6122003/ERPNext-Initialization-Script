set timeout 10

spawn sudo adduser erp

expect "New password:"
send "123\r"

expect "Retype new password"
send "123\r"

expect  "Full Name []:"
send "\r"

expect "Room Number []:"
send "\r"

expect "Work Phone []:"
send "\r"

expect "Home Phone []:"
send "\r"

expect "Other []:"
send "\r"

expect "Is the information correct? [Y\n]"
send "Y\r"

expect eof
