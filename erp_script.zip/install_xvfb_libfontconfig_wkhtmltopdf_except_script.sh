set timeout 10

sudo apt-get install xvfb libfontconfig wkhtmltopdf

expect "Do you want to continue? [Y/n]"
send "Y\r"

expect eof
