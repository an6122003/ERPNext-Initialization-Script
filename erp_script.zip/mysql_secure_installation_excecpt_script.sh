set timeout 10

sudo mysql_secure_installation

expect "Enter current password for root (enter for none): "
send "\r"

expect "Switch to unix_socket authentication [Y/n]"
send "n\r"

expect "Change the root password? [Y/n]"
send "n\r"

except "Remove anonymous users? [Y/n]"
send "Y\r"

except "Disallow root login remotely? [Y/n]"
send "Y\r"

except "Remove test database and access to it? [Y/n]"
send "Y\r"

except "Reload privilege tables now? [Y/n]"
send "Y\r"

expect eof
