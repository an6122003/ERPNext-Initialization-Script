set timeout 10

spawn sudo apt-get install python3.10-venv

expect "Do you want to continue? [Y/n]"
send "Y\r"

expect eof
