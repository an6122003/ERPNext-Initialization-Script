set timeout 10

spawn sudo apt-get install redis-server

expect "Do you want to continue? [Y/n]"
send "Y\r"

expect eof
