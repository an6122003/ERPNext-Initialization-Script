set timeout 10

spawn sudo apt-get install software-properties-common

expect "Do you want to continue? [Y/n]"
send "Y\r"

expect eof
