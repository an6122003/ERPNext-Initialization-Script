set timeout 10

set prompt ">>>"

spawn python3

expect -re $prompt

send "\032"

expect eof
