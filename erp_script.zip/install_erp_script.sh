sudo apt-get update
sudo apt-get install expect -y

sudo adduser erp
chmod +x adduser_except_script.sh 
setup.sh

sudo usermod -aG sudo erp
su erp
chmod +x su_except_script.sh
su_except_script.sh

cd 

python3
chmod +x stop_python3_except_script.sh
stop_python3_except_script.sh

sudo apt-get install python3-dev python3.10-dev python3-setuptools python3-pip python3-distutils
chmod +x install_python3_except_script.sh
install_python3_except_script.sh

sudo apt-get install python3.10-venv
chmod +x install_python3_venv_except_script.sh
install_python3_venv_except_script.sh

sudo apt-get install software-properties-common
chmod +x install_sofware_properties_common_except_script.sh
install_sofware_properties_common_except_script.sh

sudo apt install mariadb-server mariadb-client
chmod +x install_mariadb_except_script.sh
install_mariadb_except_script.sh

sudo apt-get install redis-server
chmod +x install_redis_server_except_script.sh
install_redis_server_except_script.sh

sudo apt-get install xvfb libfontconfig wkhtmltopdf
chmod +x install_xvfb_libfontconfig_wkhtmltopdf_except_script.sh
install_xvfb_libfontconfig_wkhtmltopdf_except_script.sh

sudo apt-get install libmysqlclient-dev
chmod +x install_libmysqlclient_dev_except_script.sh
install_libmysqlclient_dev_except_script.sh

sudo mysql_secure_installation
chmod +x mysql_secure_installation_except_script.sh
mysql_secure_installation_except_script.sh



