set timeout 10

spawn sudo apt-get install python3-dev python3.10-dev python3-setuptools python3-pip python3-distutils

expect "[sudo] password for erp:"
send "123\r"

expect "Do you want to continue? [Y/n]"
send "Y\r"

expect eof
