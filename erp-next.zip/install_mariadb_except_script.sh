set timeout 10

spawn sudo apt install mariadb-server mariadb-client

expect "Do you want to continue? [Y/n]"
send "Y\r"

expect eof
