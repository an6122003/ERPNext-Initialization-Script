set timeout 10

sudo apt-get install libmysqlclient-dev

expect "Do you want to continue? [Y/n]"
send "Y\r"

expect eof
