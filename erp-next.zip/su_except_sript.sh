set timeout 10

spawn su erp

expect "Password:"
send "123\r"

expect eof

